import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MatDividerModule } from '@angular/material/divider'; 

@Component({
  selector: 'app-filipino',
  imports: [
    CommonModule,
    HttpClientModule,
    MatDividerModule
  ],
  templateUrl: './filipino.html',
  styleUrl: './filipino.css',
})
export class Filipino {
  foods: any[] = [];
  foodIDs = ['53072', '53075', '53068'];

  constructor(private http: HttpClient) {
    this.foodIDs.forEach(id => {
      this.http.get(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${id}`)
      .subscribe({
        next: (response: any) => {
          if (response.meals) {
            this.foods.push(response.meals[0]);
          }
        },
        error: (error) => console.error('Error:', error)
      });
    });
  }
}