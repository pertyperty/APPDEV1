import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Filipino } from './filipino';

describe('Filipino', () => {
  let component: Filipino;
  let fixture: ComponentFixture<Filipino>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Filipino]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Filipino);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
