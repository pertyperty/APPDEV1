import { ComponentFixture, TestBed } from '@angular/core/testing';

import { American } from './american';

describe('American', () => {
  let component: American;
  let fixture: ComponentFixture<American>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [American]
    })
    .compileComponents();

    fixture = TestBed.createComponent(American);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
