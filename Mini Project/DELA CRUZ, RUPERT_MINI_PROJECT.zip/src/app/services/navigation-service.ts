import { Injectable, signal } from '@angular/core';

export type PokemonType = 'fire' | 'water' | 'grass'

@Injectable({
  providedIn: 'root'
})
export class NavigationService {
  private types: PokemonType[] = ['fire', 'water', 'grass'];
  private index = signal(0);

  currentType = signal<PokemonType>(this.types[this.index()]);

  next(): void {
    const i = (this.index() + 1) % this.types.length;
    this.index.set(i);
    this.currentType.set(this.types[i]);
  }

  previous(): void {
    const i = (this.index() - 1 + this.types.length) % this.types.length;
    this.index.set(i);
    this.currentType.set(this.types[i]);
  }
}
