import { Injectable, signal } from '@angular/core';

export interface PokemonInfo {
  name: string;
  id: number;
  sprites: {
    front_default?: string;
  };
  stats: Array<{
    base_stat: number;
    stat: {
      name: string
    }
  }>;
}

type EvoStage = 0 | 1 | 2 ;

@Injectable({
  providedIn: 'root'
})
export class WaterPokemonService {
  names: string[] = [ 'totodile', 'croconaw', 'feraligatr' ];
  stage = signal<EvoStage>(0);
  loading = signal(false);
  data = signal<PokemonInfo | null>(null);
  error = signal<string | null>(null);

  fetchCurrent(): void {
    const name = this.names[this.stage()];
    this.fetchByName(name);
  }

  fetchByName(name: string): void {
    this.loading.set(true);
    this.error.set(null);
    fetch(`https://pokeapi.co/api/v2/pokemon/${name}`)
      .then(res => {
        if (!res.ok) throw new Error(`Failed to load ${name}`);
        return res.json() as Promise<PokemonInfo>;
      })
      .then(json => this.data.set(json))
      .catch((e: any) => this.error.set(e?.message ?? 'Unknown error'))
      .finally(() => this.loading.set(false));
  }

  canEvolve(): boolean {
    return this.stage() < 2;
  }
  canRevert(): boolean {
    return this.stage() > 0;
  }

  evolve(): void {
    if (!this.canEvolve()) return;
    this.stage.set((this.stage() + 1) as EvoStage);
    this.fetchCurrent();
  }

  revert(): void {
    if (!this.canRevert()) return;
    this.stage.set((this.stage() - 1) as EvoStage);
    this.fetchCurrent();
  }
}
