import { Component, inject } from '@angular/core';
import { WaterPokemonService } from '../../services/water-pokemon-service';

@Component({
  selector: 'app-water-pokemon',
  standalone: false,
  templateUrl: './water-pokemon.html',
  styleUrl: './water-pokemon.css'
})
export class WaterPokemon {
  service = inject(WaterPokemonService)
  data = this.service.data;
  loading = this.service.loading;
  stage = this.service.stage;

  ngOnInit() {
    if (!this.data()) {
      this.service.fetchCurrent();
    }
  }

  evolve() { this.service.evolve(); }
  revert() { this.service.revert(); }
  canEvolve() { return this.service.canEvolve(); }
  canRevert() { return this.service.canRevert(); }
}
