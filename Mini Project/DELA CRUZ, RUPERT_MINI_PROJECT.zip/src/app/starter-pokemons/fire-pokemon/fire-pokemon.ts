import { Component, inject } from '@angular/core';
import { FirePokemonService } from '../../services/fire-pokemon-service';

@Component({
  selector: 'app-fire-pokemon',
  standalone: false,
  templateUrl: './fire-pokemon.html',
  styleUrl: './fire-pokemon.css'
})
export class FirePokemon {
  service = inject(FirePokemonService)
  data = this.service.data;
  loading = this.service.loading;
  stage = this.service.stage;

  ngOnInit() {
    if (!this.data()) {
      this.service.fetchCurrent();
    }
  }

  evolve() { this.service.evolve(); }
  revert() { this.service.revert(); }
  canEvolve() { return this.service.canEvolve(); }
  canRevert() { return this.service.canRevert(); }
}
