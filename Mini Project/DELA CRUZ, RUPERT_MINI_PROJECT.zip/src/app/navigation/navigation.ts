import { Component, inject } from '@angular/core';
import { NavigationService } from '../services/navigation-service';

@Component({
  selector: 'app-navigation',
  standalone: false,
  templateUrl: './navigation.html',
  styleUrl: './navigation.css'
})
export class Navigation {
  private selection = inject(NavigationService);

  previous() {
    this.selection.previous();
  }

  next() {
    this.selection.next();
  }
}
