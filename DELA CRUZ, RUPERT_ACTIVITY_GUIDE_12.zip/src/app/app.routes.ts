import { Routes } from '@angular/router';
import { Home } from './home/home';
import { Filipino } from './foods/filipino/filipino';
import { Japanese } from './foods/japanese/japanese';
import { American } from './foods/american/american';

export const routes: Routes = [
  {path: '', component: Home, pathMatch: 'full'},
  {path: 'ph', component: Filipino},
  {path: 'jp', component: Japanese},
  {path: 'us', component: American},
];
