import { Component, computed, inject } from '@angular/core';
import { NavigationService } from '../services/navigation-service';

@Component({
  selector: 'app-home',
  standalone: false,
  templateUrl: './home.html',
  styleUrl: './home.css'
})
export class Home {
  private selection = inject(NavigationService);

  currentType = this.selection.currentType;
  isFire = computed(() => this.currentType() === 'fire');
  isWater = computed(() => this.currentType() === 'water');
  isGrass = computed(() => this.currentType() === 'grass');
}
