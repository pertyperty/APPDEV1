import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { WaterPokemon } from './starter-pokemons/water-pokemon/water-pokemon';
import { FirePokemon } from './starter-pokemons/fire-pokemon/fire-pokemon';
import { GrassPokemon } from './starter-pokemons/grass-pokemon/grass-pokemon';
import { Footer } from './footer/footer';
import { Header } from './header/header';
import { Home } from './home/home';
import { Navigation } from './navigation/navigation';

@NgModule({
  declarations: [
    App,
    WaterPokemon,
    FirePokemon,
    GrassPokemon,
    Footer,
    Header,
    Home,
    Navigation
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [
    provideBrowserGlobalErrorListeners()
  ],
  bootstrap: [App]
})
export class AppModule { }
