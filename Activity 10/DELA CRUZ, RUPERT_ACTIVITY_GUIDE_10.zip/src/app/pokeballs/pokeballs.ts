import { Component } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { PokeballsService } from '../pokeballs-service';

@Component({
  selector: 'app-pokeballs',
  standalone: true,
  imports: [MatTableModule],
  templateUrl: './pokeballs.html',
  styleUrl: './pokeballs.css'
})
export class Pokeballs {
  dataSource: {name: string; img: string; indexNum: string; catchRateMod: { note: string }[] }[] = [];

  constructor(private p: PokeballsService) {}

  ngOnInit(): void {
    console.log('ngOnInit called');
    this.dataSource = this.p.getPokeballs();
  }

  displayedColumns: string[] = ['img', 'name', 'indexNum', 'catchRateMod']
}
