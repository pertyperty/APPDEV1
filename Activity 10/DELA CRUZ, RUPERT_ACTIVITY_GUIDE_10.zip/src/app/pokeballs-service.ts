import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PokeballsService {
  getPokeballs() {
    return [
      {
        name: 'Poké Ball', img: '/Pokeballs/pokeball.png',
        indexNum: '04', 
        catchRateMod: [
          {note: '1.0x'}
        ]
      },
      {
        name: 'Great Ball', img: '/Pokeballs/greatball.png',
        indexNum: '03',
        catchRateMod: [
          {note: '1.5x'}
        ]
      },
      {
        name: 'Ultra Ball', img: '/Pokeballs/ultraball.png',
        indexNum: '02',
        catchRateMod: [
          {note: '2.0x'}
        ]
      },
      {
        name: 'Master Ball', img: '/Pokeballs/masterball.png', 
        indexNum: '01',
        catchRateMod: [
          {note: 'Guaranteed'}
        ]
      },
      {
        name: 'Safari Ball', img: '/Pokeballs/safariball.png', 
        indexNum: '01', 
        catchRateMod: [
          {note: '1.0x'}
        ] 
      },
      {
        name: 'Fast Ball', img: '/Pokeballs/fastball.png', 
        indexNum: '17', 
        catchRateMod: [
          {note: '4.0x if used on a Pokémon with a base Speed of at least 100'},
          {note: '1.0x otherwise'},
        ]  
      },
      {
        name: 'Level Ball', img: '/Pokeballs/levelball.png', 
        indexNum: '18',
        catchRateMod: [
          {note: '1.0x if the player\'s Pokémon is the same level as or a lower level than the wild Pokémon'},
          {note: '2.0x if the player\'s Pokémon is at a higher level than the wild Pokémon but less than double it'},
          {note: '4.0x if the player\'s Pokémon is more than double but less than four times the level of the wild Pokémon'},
          {note: '8.0x if the player\'s Pokémon is of a level four times or more than that of the wild Pokémon'}
        ] 
      },
      {
        name: 'Lure Ball', img: '/Pokeballs/lureball.png', 
        indexNum: '19',
        catchRateMod: [
          {note: '4.0x if used on a Pokémon encountered while fishing'},
          {note: '1.0x otherwise'}
        ]  
      },
      {
        name: 'Heavy Ball', img: '/Pokeballs/heavyball.png', 
        indexNum: '20',
        catchRateMod: [
          {note: '-20 if used on a Pokémon weighing 220.2 lbs. (99.9 kg) or less'},
          {note: '±0 if used on a Pokémon weighing 220.5 lbs. (100.0 kg) - 440.7 lbs. (199.9 kg)'},
          {note: '+20 if used on a Pokémon weighing 440.9 lbs. (200.0 kg) - 661.2 lbs. (299.9 kg)'},
          {note: '+30 if used on a Pokémon weighing 661.4 lbs. (300.0 kg) or more'}
        ] 
      },
      {
        name: 'Love Ball', img: '/Pokeballs/loveball.png', 
        indexNum: '21',
        catchRateMod: [
          {note: '8.0x if used on a Pokémon of the same species but opposite gender of the player\'s Pokémon'},
          {note: '1.0x otherwise'},
        ] 
      },
      {
        name: 'Friend Ball', img: '/Pokeballs/friendball.png', 
        indexNum: '22',
        catchRateMod: [
          {note: '1.0x'},
        ] 
      },
      {
        name: 'Moon Ball', img: '/Pokeballs/moonball.png', 
        indexNum: '23',
        catchRateMod: [
          {note: '4.0x if used on a Pokémon that evolves by using a Moon Stone'},
          {note: '1.0x otherwise'},
        ] 
      },
      {
        name: 'Sport Ball', img: '/Pokeballs/sportball.png', 
        indexNum: '24',
        catchRateMod: [
          {note: '1.0x'},
        ] 
      },
    ]
  }
}
