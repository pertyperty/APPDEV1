import { Component } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { BerriesService } from '../berries-service';

@Component({
  selector: 'app-berries',
  standalone: true,
  imports: [MatTableModule],
  templateUrl: './berries.html',
  styleUrl: './berries.css'
})
export class Berries {
  dataSource: {name: string; effect: string}[] = [];

  constructor(private b: BerriesService) {}

  ngOnInit(): void {
    console.log('ngOnInit called');
    this.dataSource = this.b.getBerries();
  }

  displayedColumns: string[] = ['name', 'effect'];
}
