// Local development configuration that mirrors production shape for DI tokens.
export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000'
};
