// Application defaults for production builds (toggled via environment replacements).
export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000'
};
