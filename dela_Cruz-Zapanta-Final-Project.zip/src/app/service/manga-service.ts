import { Injectable } from '@angular/core';
import { JikanClient, Manga as MangaResource, MangaSearchParams } from '@tutkli/jikan-ts';

// Thin wrapper over Jikan’s manga endpoints for search and rankings.
@Injectable({
  providedIn: 'root',
})
export class MangaService {
  private readonly client = new JikanClient({
    cacheOptions: { ttl: 1000 * 60 * 5 },
    enableLogging: false,
  });

  private readonly mangaClient = this.client.manga;
  private readonly topClient = this.client.top;

  // Query Jikan for manga that satisfy the search criteria.
  async searchManga(
    query: string,
    overrides: Partial<MangaSearchParams> = {}
  ): Promise<MangaResource[]> {
    const params: Partial<MangaSearchParams> = {
      q: query,
      limit: 15,
      order_by: 'score',
      sort: 'desc',
      ...overrides,
    };

    const response = await this.mangaClient.getMangaSearch(params);
    return response.data;
  }

  // Fetch the most popular manga to support decorative UI like background carousels.
  async getPopularManga(limit = 12): Promise<MangaResource[]> {
    const response = await this.topClient.getTopManga({ filter: 'bypopularity', limit });
    return response.data;
  }
}

// Mirror of AnimeItem for consumers that operate on manga resources.
export type MangaItem = MangaResource;
