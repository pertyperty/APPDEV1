import { Injectable } from '@angular/core';
import { JikanClient, Anime as AnimeResource, AnimeSearchParams } from '@tutkli/jikan-ts';

// Centralized gateway around the Jikan anime endpoints.
@Injectable({
  providedIn: 'root',
})
export class AnimeService {
  private readonly client = new JikanClient({
    cacheOptions: { ttl: 1000 * 60 * 5 },
    enableLogging: false,
  });

  private readonly animeClient = this.client.anime;
  private readonly randomClient = this.client.random;
  private readonly topClient = this.client.top;

  // Take a single random anime from the Jikan API.
  async getRandomAnime(): Promise<AnimeResource> {
    const response = await this.randomClient.getRandomAnime();
    return response.data;
  }

  // Query Jikan for anime matching the given search string and parametersss.
  async searchAnime(
    query: string,
    overrides: Partial<AnimeSearchParams> = {}
  ): Promise<AnimeResource[]> {
    const params: Partial<AnimeSearchParams> = {
      q: query,
      limit: 24,
      order_by: "score",
      sort: "desc",
      unapproved: true,
      ...overrides,
    };

    const response = await this.animeClient.getAnimeSearch(params);
    return response.data;
  }

  // Fetch the most popular anime according to MAL rankings for use in hero visuals.
  async getPopularAnime(limit = 12): Promise<AnimeResource[]> {
    const response = await this.topClient.getTopAnime({ filter: 'bypopularity', limit });
    return response.data;
  }

  // We can add consumet API to allow watching animes :>
}

// Convenient alias exposed to components for strongly typed anime entries.
export type AnimeItem = AnimeResource;
