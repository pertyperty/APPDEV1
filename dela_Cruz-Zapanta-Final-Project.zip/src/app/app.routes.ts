import { Routes } from '@angular/router';
import { Home } from './pages/home/home';
import { Forum } from './pages/forum/forum';
import { Profile } from './pages/profile/profile';

// Defines the top-level navigation map for the standalone router.
export const routes: Routes = [
	{
		path: '',
		component: Home,
		pathMatch: 'full',
	},
	{
		path: 'forum',
		component: Forum,
	},
	{
		path: 'profile',
		component: Profile,
	},
];
