import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatDividerModule } from '@angular/material/divider';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';

// Restrict supported embeds to the two renderer paths handled by the UI.
type EmbedType = 'video' | 'image';

// Shape of posts captured in the in-memory forum feed.
interface ForumPost {
  id: number;
  title: string;
  description: string;
  embedUrl?: string;
  embedType?: EmbedType;
  createdAt: Date;
  author: string;
}

@Component({
  selector: 'app-forum',
  standalone: true,
  imports: [CommonModule, FormsModule, MatDividerModule],
  templateUrl: './forum.html',
  styleUrl: './forum.css',
})
export class Forum {
  protected readonly currentUser = 'Guest NH User';
  protected postForm: { title: string; description: string; embedUrl: string; embedType: EmbedType } = {
    title: '',
    description: '',
    embedUrl: '',
    embedType: 'video',
  };
  protected posts: ForumPost[] = [];

  private nextId = this.posts.length + 1;

  // Inject sanitizer utilities for safe iframe URLs.
  constructor(private readonly sanitizer: DomSanitizer) {}

  // Persist the composed post into local state after validating required fields.
  protected submitPost(): void {
  const title = this.postForm.title.trim();
  const description = this.postForm.description.trim();
  const embedUrl = this.postForm.embedUrl.trim();

  if (!title || !description) {
    return;
  }

  const newPost: ForumPost = {
    id: this.nextId++,
    title,
    description,
    embedUrl: embedUrl || undefined,
    embedType: embedUrl ? this.postForm.embedType : undefined,
    createdAt: new Date(),
    author: this.currentUser,
  };

  this.posts = [newPost, ...this.posts];
  this.postForm = { title: '', description: '', embedUrl: '', embedType: this.postForm.embedType };
  }

  // Reset the composer for the next post.
  protected resetForm(): void {
  this.postForm = { title: '', description: '', embedUrl: '', embedType: 'video' };
  }

  // Provide a stable identity for @for rendering.
  protected trackByPost(_index: number, post: ForumPost): number {
  return post.id;
  }

  // Human-readable formatting for the post creation time.
  protected formatTimestamp(date: Date): string {
  return new Intl.DateTimeFormat('en', {
    dateStyle: 'medium',
    timeStyle: 'short',
  }).format(date);
  }

  // Build a safe embeddable URL for supported video providers.
  protected embedPreview(post: ForumPost): SafeResourceUrl | null {
  if (!post.embedUrl || post.embedType !== 'video') {
    return null;
  }

  const normalized = this.normalizeVideoUrl(post.embedUrl);
  return normalized ? this.sanitizer.bypassSecurityTrustResourceUrl(normalized) : null;
  }

  // Detect whether the post should render an image embed.
  protected isImagePost(post: ForumPost): boolean {
  return post.embedType === 'image' && !!post.embedUrl;
  }

  // Determine if a video iframe should be rendered.
  protected hasVideo(post: ForumPost): boolean {
  return post.embedType === 'video' && !!post.embedUrl;
  }

  // Normalize arbitrary video URLs into embeddable forms.
  private normalizeVideoUrl(rawUrl: string): string | null {
  try {
    const url = new URL(rawUrl);
    if (url.hostname.includes('youtube.com')) {
      const videoId = url.searchParams.get('v');
      if (videoId) {
        return `https://www.youtube.com/embed/${videoId}`;
      }
      if (url.pathname.startsWith('/embed/')) {
        return url.toString();
      }
    }
    if (url.hostname === 'youtu.be') {
      const id = url.pathname.replace('/', '');
      return id ? `https://www.youtube.com/embed/${id}` : null;
    }
    return rawUrl;
  } catch {
    return null;
  }
  }

}
