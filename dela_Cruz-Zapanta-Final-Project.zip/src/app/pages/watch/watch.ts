import { Component } from '@angular/core';

@Component({
  selector: 'app-watch',
  imports: [],
  templateUrl: './watch.html',
  styleUrl: './watch.css',
})
export class Watch {}
