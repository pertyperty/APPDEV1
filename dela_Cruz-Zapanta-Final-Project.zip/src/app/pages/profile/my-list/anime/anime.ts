import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

// Presentation component for the anime entries within the profile page.
@Component({
  selector: 'app-profile-anime-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './anime.html',
  styleUrl: './anime.css',
})
export class ProfileAnimeList {
  @Input() entries: UserEntry[] = [];
  @Output() editRequested = new EventEmitter<UserEntry>();
  @Output() deleteRequested = new EventEmitter<UserEntry>();
}

// Entry shape forwarded from parent lists.
interface UserEntry {
  id: number;
  title: string;
  image?: string;
  rating?: number;
  notes?: string;
  status: 'ongoing' | 'dropped' | 'finished' | 'pending';
  addedAt: Date;
}
