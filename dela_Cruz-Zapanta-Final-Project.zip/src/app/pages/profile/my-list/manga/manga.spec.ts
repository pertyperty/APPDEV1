import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProfileMangaList } from './manga';

describe('ProfileMangaList', () => {
  let component: ProfileMangaList;
  let fixture: ComponentFixture<ProfileMangaList>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ProfileMangaList]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProfileMangaList);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
