import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

// Presentation component for the manga entries within the profile page.
@Component({
  selector: 'app-profile-manga-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './manga.html',
  styleUrl: './manga.css',
})
export class ProfileMangaList {
  @Input() entries: UserEntry[] = [];
  @Output() editRequested = new EventEmitter<UserEntry>();
  @Output() deleteRequested = new EventEmitter<UserEntry>();
}

// Entry shape forwarded from parent lists.
interface UserEntry {
  id: number;
  title: string;
  image?: string;
  rating?: number;
  notes?: string;
  status: 'ongoing' | 'dropped' | 'finished' | 'pending';
  addedAt: Date;
}
