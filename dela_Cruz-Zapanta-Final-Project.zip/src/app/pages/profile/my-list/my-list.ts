import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ProfileAnimeList } from './anime/anime';
import { ProfileMangaList } from './manga/manga';

// Delegates rendering of the user’s anime and manga lists to media-specific presenters.
@Component({
  selector: 'app-my-list',
  standalone: true,
  imports: [CommonModule, ProfileAnimeList, ProfileMangaList],
  templateUrl: './my-list.html',
  styleUrl: './my-list.css',
})
export class MyList {
  @Input({ required: true }) activeSection: 'anime' | 'manga' = 'anime';
  @Input({ required: true }) activeSort: SortKey = 'title';
  @Input({ required: true }) animeList: UserEntry[] = [];
  @Input({ required: true }) mangaList: UserEntry[] = [];
  @Output() editEntry = new EventEmitter<ListMutation>();
  @Output() deleteEntry = new EventEmitter<ListMutation>();

  // Produce the list currently selected in the UI, sorted with the active criteria.
  protected get sortedEntries(): UserEntry[] {
    const source = this.activeSection === 'anime' ? this.animeList : this.mangaList;
    return this.sortEntries(source);
  }

  // Bubble edit requests up to the profile container with the active media type.
  protected handleEdit(entry: UserEntry): void {
    this.editEntry.emit({ entry, type: this.activeSection });
  }

  // Bubble delete requests up to the profile container with the active media type.
  protected handleDelete(entry: UserEntry): void {
    this.deleteEntry.emit({ entry, type: this.activeSection });
  }

  // Clone and sort the given entries so the inputs remain immutable.
  private sortEntries(list: UserEntry[]): UserEntry[] {
    const data = [...list];
    if (this.activeSort === 'title') {
      return data.sort((a, b) => a.title.localeCompare(b.title));
    }
    if (this.activeSort === 'rating') {
      return data.sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0));
    }
    return data.sort((a, b) => b.addedAt.getTime() - a.addedAt.getTime());
  }
}

// Mirror of the profile sort options scoped to this component.
type SortKey = 'title' | 'rating' | 'date';

// Lightweight entry contract consumed by the list presenters.
interface UserEntry {
  id: number;
  title: string;
  image?: string;
  rating?: number;
  notes?: string;
  status: 'ongoing' | 'dropped' | 'finished' | 'pending';
  addedAt: Date;
}

interface ListMutation {
  entry: UserEntry;
  type: 'anime' | 'manga';
}
