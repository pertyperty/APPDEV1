import { CommonModule } from '@angular/common';
import { Component, OnDestroy } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatDividerModule } from '@angular/material/divider';
import { AnimeService, AnimeItem } from '../../service/anime-service';
import { MangaService, MangaItem } from '../../service/manga-service';
import { MyList } from './my-list/my-list';

// Full-screen experience for managing personal anime/manga lists.
@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, FormsModule, MatDividerModule, MyList],
  templateUrl: './profile.html',
  styleUrl: './profile.css',
})
export class Profile implements OnDestroy {
  protected readonly sortOptions: SortOption[] = [
    { label: 'Title', value: 'title' },
    { label: 'Personal Rating', value: 'rating' },
    { label: 'Date Added', value: 'date' },
  ];

  protected activeSection: 'anime' | 'manga' = 'anime';
  protected activeSort: SortKey = 'title';

  protected animeList: UserEntry[] = [];
  protected mangaList: UserEntry[] = [];

  protected showDialog = false;
  protected dialogType: 'anime' | 'manga' = 'anime';
  protected dialogForm: DialogFormData = {
    search: '',
    selected: null,
    rating: 0,
    notes: '',
    status: 'ongoing',
  };

  protected searchResults: Array<AnimeItem | MangaItem> = [];
  protected searchLoading = false;
  protected searchError = '';
  protected isEditing = false;

  private searchTimer: ReturnType<typeof setTimeout> | null = null;
  private activeRequestId = 0;
  private editingEntryId: number | null = null;
  private editingEntryType: 'anime' | 'manga' | null = null;

  // Inject the media services used by the search dialog.
  constructor(
    private readonly animeService: AnimeService,
    private readonly mangaService: MangaService
  ) {}

  // Ensure pending debounced searches do not continue after destruction.
  ngOnDestroy(): void {
    this.cancelPendingSearch(true);
  }

  // Toggle the list between anime and manga entries.
  protected setSection(section: 'anime' | 'manga'): void {
    this.activeSection = section;
  }

  // Update the sort key used by the list view.
  protected setSort(sort: SortKey): void {
    this.activeSort = sort;
  }

  // Initialize and display the add-to-list dialog for the requested media type.
  protected openDialog(type: 'anime' | 'manga', entry?: UserEntry): void {
    this.dialogType = type;
    this.isEditing = !!entry;
    this.editingEntryId = entry?.id ?? null;
    this.editingEntryType = entry ? type : null;
    this.dialogForm = entry
      ? {
          search: entry.title,
          selected: null,
          rating: entry.rating ?? 0,
          notes: entry.notes ?? '',
          status: entry.status,
        }
      : { search: '', selected: null, rating: 0, notes: '', status: 'ongoing' };
    this.searchError = '';

    if (this.isEditing) {
      this.cancelPendingSearch(true);
      this.searchResults = [];
      this.searchLoading = false;
    } else {
      this.resetSearchState();
    }

    this.showDialog = true;
  }

  // Hide the dialog and stop any in-flight search.
  protected closeDialog(): void {
    this.showDialog = false;
    this.cancelPendingSearch(true);
    this.isEditing = false;
    this.editingEntryId = null;
    this.editingEntryType = null;
  }

  // Handle debounced search input changes for the dialog lookup.
  protected onSearchInput(query: string): void {
    if (this.isEditing) {
      return;
    }
    this.dialogForm.search = query;
    this.dialogForm.selected = null;
    this.searchError = '';
    const trimmed = query.trim();

    if (!trimmed) {
      this.resetSearchState();
      return;
    }

    this.scheduleSearch(this.dialogType, trimmed);
  }

  // Select a search result and sync the input text to its title.
  protected selectResult(result: AnimeItem | MangaItem): void {
    this.dialogForm.selected = result;
    this.dialogForm.search = result.title;
  }

  // Validate the dialog form and append the chosen item to the proper list.
  protected submitDialog(): void {
    if (this.isEditing) {
      this.applyEdit();
      return;
    }

    if (!this.dialogForm.selected) {
      this.searchError = 'Please select an item to add.';
      return;
    }

    const entry: UserEntry = {
      id: this.dialogForm.selected.mal_id,
      title: this.dialogForm.selected.title,
      image: this.dialogForm.selected.images?.jpg?.image_url || '',
      rating: this.dialogForm.rating,
      notes: this.dialogForm.notes,
      status: this.dialogForm.status,
      addedAt: new Date(),
    };

    if (this.dialogType === 'anime') {
      this.animeList = [...this.animeList, entry];
    } else {
      this.mangaList = [...this.mangaList, entry];
    }

    this.closeDialog();
  }

  // Receive edit intents from the list component and seed the dialog with entry data.
  protected onEditEntry(event: ListMutation): void {
    this.openDialog(event.type, event.entry);
  }

  // Remove the chosen entry from whichever list emitted the delete event.
  protected onDeleteEntry(event: ListMutation): void {
    if (event.type === 'anime') {
      this.animeList = this.animeList.filter((item) => item.id !== event.entry.id);
    } else {
      this.mangaList = this.mangaList.filter((item) => item.id !== event.entry.id);
    }
  }

  // Debounce search calls so quick typing does not spam the API.
  private scheduleSearch(type: 'anime' | 'manga', query: string): void {
    this.clearSearchTimer();
    const requestId = ++this.activeRequestId;
    this.searchLoading = true;

    this.searchTimer = globalThis.setTimeout(() => {
      this.searchTimer = null;
      void this.executeSearch(type, query, requestId);
    }, 300);
  }

  // Execute the remote search and only commit results if still current.
  private async executeSearch(
    type: 'anime' | 'manga',
    query: string,
    requestId: number
  ): Promise<void> {
    try {
      const results =
        type === 'anime'
          ? await this.animeService.searchAnime(query, { limit: 20 })
          : await this.mangaService.searchManga(query, { limit: 5 });

      if (requestId === this.activeRequestId) {
        this.searchResults = results;
        this.searchError = '';
      }
    } catch {
      if (requestId === this.activeRequestId) {
        this.searchResults = [];
        this.searchError = 'Unable to search right now.';
      }
    } finally {
      if (requestId === this.activeRequestId) {
        this.searchLoading = false;
      }
    }
  }

  // Reset UI state for the search results and loading indicator.
  private resetSearchState(): void {
    this.cancelPendingSearch(true);
    this.searchResults = [];
    this.searchLoading = false;
  }

  // Stop pending timers and optionally bump the request id to ignore late responses.
  private cancelPendingSearch(incrementId = false): void {
    this.clearSearchTimer();
    if (incrementId) {
      this.activeRequestId++;
    }
  }

  // Clear the outstanding debounce timer if it exists.
  private clearSearchTimer(): void {
    if (this.searchTimer) {
      clearTimeout(this.searchTimer);
      this.searchTimer = null;
    }
  }

  // Update an existing entry with the dialog's note/rating/status changes.
  private applyEdit(): void {
    if (!this.isEditing || this.editingEntryId === null || !this.editingEntryType) {
      return;
    }

    const list = this.editingEntryType === 'anime' ? [...this.animeList] : [...this.mangaList];
    const index = list.findIndex((entry) => entry.id === this.editingEntryId);
    if (index === -1) {
      this.closeDialog();
      return;
    }

    list[index] = {
      ...list[index],
      rating: this.dialogForm.rating,
      notes: this.dialogForm.notes,
      status: this.dialogForm.status,
    };

    if (this.editingEntryType === 'anime') {
      this.animeList = list;
    } else {
      this.mangaList = list;
    }

    this.closeDialog();
  }

}

// Option definition for the sort dropdown in the profile view.
interface SortOption {
  label: string;
  value: SortKey;
}

// Supported columns the list can be sorted by.
type SortKey = 'title' | 'rating' | 'date';

// Canonical shape of an anime/manga entry saved to the user's list.
interface UserEntry {
  id: number;
  title: string;
  image?: string;
  rating?: number;
  notes?: string;
  status: 'ongoing' | 'dropped' | 'finished' | 'pending';
  addedAt: Date;
}

// Internal form state driving the add-entry dialog.
interface DialogFormData {
  search: string;
  selected: AnimeItem | MangaItem | null;
  rating: number;
  notes: string;
  status: 'ongoing' | 'dropped' | 'finished' | 'pending';
}

interface ListMutation {
  entry: UserEntry;
  type: 'anime' | 'manga';
}
