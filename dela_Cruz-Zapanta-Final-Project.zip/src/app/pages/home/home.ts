import { CommonModule } from '@angular/common';
import { Component, OnInit, inject } from '@angular/core';
import { MatDividerModule } from '@angular/material/divider';
import { AnimeService, AnimeItem } from '../../service/anime-service';
import { MangaService, MangaItem } from '../../service/manga-service';
import { Anime as AnimeSearchSection } from './anime/anime';
import { Manga as MangaSearchSection } from './manga/manga';

// Landing page that mixes hero content, search panels, and decorative carousels.
@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, MatDividerModule, AnimeSearchSection, MangaSearchSection],
  templateUrl: './home.html',
  styleUrl: './home.css',
})
export class Home implements OnInit {
  protected selectedCategory: 'anime' | 'manga' = 'anime';
  protected randomAnime?: AnimeItem;
  protected randomLoading = false;
  protected randomError = '';
  protected synopsisExpanded = false;
  protected readonly synopsisLimit = 250;
  protected popularAnime: AnimeItem[] = [];
  protected popularManga: MangaItem[] = [];
  protected carouselItems: Array<AnimeItem | MangaItem> = [];
  protected popularLoading = false;
  protected popularError = '';

  private readonly animeService = inject(AnimeService);
  private readonly mangaService = inject(MangaService);
  private pendingPopularRequests = 0;

  // Kick off the hero card fetch and background carousel sources when the view loads.
  ngOnInit(): void {
    void this.loadRandomAnime();
    void this.loadPopularAnime();
    void this.loadPopularManga();
  }

  // Switch the search panel between anime and manga sections.
  protected selectCategory(category: 'anime' | 'manga'): void {
    this.selectedCategory = category;
  }

  // Retrieve a random anime from the API and manage loading/error state.
  protected async loadRandomAnime(): Promise<void> {
    this.randomLoading = true;
    this.randomError = '';

    try {
      const anime = await this.animeService.getRandomAnime();
      this.randomAnime = anime;
      this.synopsisExpanded = false;
    } catch {
      this.randomError = 'Unable to fetch a random anime right now. Please try again later.';
    } finally {
      this.randomLoading = false;
    }
  }

  // Expand or collapse the synopsis preview when toggling is allowed.
  protected toggleSynopsis(): void {
    if (!this.canToggleSynopsis) {
      return;
    }
    this.synopsisExpanded = !this.synopsisExpanded;
  }

  // Produce the trimmed or full synopsis string shown in the UI.
  protected get synopsisDisplayText(): string {
    const synopsis = this.randomAnime?.synopsis?.trim();
    if (!synopsis) {
      return 'No synopsis available for this title yet.';
    }

    if (this.synopsisExpanded || synopsis.length <= this.synopsisLimit) {
      return synopsis;
    }

    return synopsis.slice(0, this.synopsisLimit).trimEnd() + '…';
  }

  // Determine if the synopsis exceeds the preview limit to show the toggle.
  protected get canToggleSynopsis(): boolean {
    const synopsis = this.randomAnime?.synopsis;
    return !!synopsis && synopsis.length > this.synopsisLimit;
  }

  // Retrieve a slice of popular anime to populate the background carousel.
  protected async loadPopularAnime(): Promise<void> {
    this.beginPopularRequest();

    try {
      this.popularAnime = await this.animeService.getPopularAnime(10);
      this.rebuildCarouselItems();
    } catch {
      this.popularError = 'Unable to load popular titles right now.';
    } finally {
      this.endPopularRequest();
    }
  }

  // Retrieve top manga entries to mix into the hero carousel.
  protected async loadPopularManga(): Promise<void> {
    this.beginPopularRequest();

    try {
      this.popularManga = await this.mangaService.getPopularManga(10);
      this.rebuildCarouselItems();
    } catch {
      this.popularError = 'Unable to load popular titles right now.';
    } finally {
      this.endPopularRequest();
    }
  }

  // Duplicate the popular list to guarantee a seamless marquee scroll.
  protected get carouselSlides(): Array<AnimeItem | MangaItem> {
    if (!this.carouselItems.length) {
      return [];
    }

    return [...this.carouselItems, ...this.carouselItems];
  }

  // Track concurrent fetches so loading state reflects both endpoints.
  private beginPopularRequest(): void {
    this.pendingPopularRequests += 1;
    this.popularLoading = true;
    this.popularError = '';
  }

  // Reduce the pending counter and clear the loading flag when finished.
  private endPopularRequest(): void {
    this.pendingPopularRequests = Math.max(0, this.pendingPopularRequests - 1);
    if (this.pendingPopularRequests === 0) {
      this.popularLoading = false;
    }
  }

  // Merge both popular lists and regenerate the shuffled carousel source.
  private rebuildCarouselItems(): void {
    const combined = [...this.popularAnime, ...this.popularManga];
    if (!combined.length) {
      this.carouselItems = [];
      return;
    }

    this.carouselItems = this.shuffle(combined);
  }

  // Fisher-Yates shuffle to randomize the carousel order without mutating inputs.
  private shuffle<T>(items: T[]): T[] {
    const copy = [...items];
    for (let i = copy.length - 1; i > 0; i -= 1) {
      const j = Math.floor(Math.random() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }
}
