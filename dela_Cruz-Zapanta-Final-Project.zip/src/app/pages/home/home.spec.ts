import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home } from './home';
import { AnimeService, AnimeItem } from '../../service/anime-service';
import { MangaService } from '../../service/manga-service';

describe('Home', () => {
  let component: Home;
  let fixture: ComponentFixture<Home>;

  const mockAnime: AnimeItem = {
    mal_id: 1,
    title: 'Mock Anime',
    url: 'https://example.com',
    images: {
      jpg: {
        image_url: 'https://placehold.co/300x400',
        large_image_url: 'https://placehold.co/600x800',
      },
      webp: {
        image_url: 'https://placehold.co/300x400',
        large_image_url: 'https://placehold.co/600x800',
      },
    },
    trailer: {
      youtube_id: '',
      url: '',
      embed_url: '',
    },
    approved: true,
    titles: [],
    title_japanese: '',
    title_synonyms: [],
    type: 'TV',
    source: '',
    episodes: 12,
    status: 'Finished Airing',
    airing: false,
    aired: {
      from: '',
      to: '',
      prop: { from: { day: 1, month: 1, year: 2020 }, to: { day: 1, month: 1, year: 2020 }, string: '' },
    },
    duration: '',
    rating: 'pg13',
    score: 8.5,
    scored_by: 100,
    rank: 100,
    popularity: 100,
    members: 1000,
    favorites: 10,
    synopsis: 'Mock synopsis',
    background: '',
    season: 'spring',
    year: 2020,
    broadcast: { day: '', time: '', timezone: '', string: '' },
    producers: [],
    licensors: [],
    studios: [],
    genres: [],
    explicit_genres: [],
    themes: [],
    demographics: [],
    streaming: [],
  };

  const animeServiceStub = {
    getRandomAnime: () => Promise.resolve(mockAnime),
    searchAnime: () => Promise.resolve([mockAnime]),
  } as Partial<AnimeService>;

  const mangaServiceStub = {
    searchManga: () => Promise.resolve([]),
  } as Partial<MangaService>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Home],
      providers: [
        { provide: AnimeService, useValue: animeServiceStub },
        { provide: MangaService, useValue: mangaServiceStub },
      ],
    })
    .compileComponents();

    fixture = TestBed.createComponent(Home);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
