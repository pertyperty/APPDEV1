import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Anime } from './anime';
import { AnimeService } from '../../../service/anime-service';

describe('Anime', () => {
  let component: Anime;
  let fixture: ComponentFixture<Anime>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Anime],
      providers: [
        {
          provide: AnimeService,
          useValue: {
            searchAnime: () => Promise.resolve([]),
          },
        },
      ],
    })
    .compileComponents();

    fixture = TestBed.createComponent(Anime);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
