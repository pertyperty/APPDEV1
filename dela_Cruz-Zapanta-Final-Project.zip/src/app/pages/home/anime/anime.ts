import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AnimeItem, AnimeService } from '../../../service/anime-service';

// Search form and results grid for the Anime tab on the home page.
@Component({
  selector: 'app-anime',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './anime.html',
  styleUrl: './anime.css',
})
export class Anime {
  protected query = '';
  protected results: AnimeItem[] = [];
  protected loading = false;
  protected error = '';
  protected hasSearched = false;
  protected visibleCount = 0;
  private readonly batchSize = 6;

  private readonly animeService = inject(AnimeService);

  // Execute the anime search workflow, handling validation, loading, and errors.
  protected async onSearch(): Promise<void> {
    const trimmedQuery = this.query.trim();
    if (!trimmedQuery) {
      this.results = [];
      this.hasSearched = false;
      this.visibleCount = 0;
      return;
    }

    this.loading = true;
    this.error = '';
    this.hasSearched = true;

    try {
      this.results = await this.animeService.searchAnime(trimmedQuery);
      this.visibleCount = Math.min(this.batchSize, this.results.length);
    } catch {
      this.error = 'Search is temporarily unavailable. Please try again shortly.';
    } finally {
      this.loading = false;
    }
  }

  // Slice the search results to the amount currently visible on screen.
  protected get visibleResults(): AnimeItem[] {
    return this.results.slice(0, this.visibleCount || this.batchSize);
  }

  // Expand the results list by another batch when the user requests more.
  protected showMoreResults(): void {
    this.visibleCount = Math.min(this.visibleCount + this.batchSize, this.results.length);
  }
}
