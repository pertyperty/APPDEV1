import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MangaItem, MangaService } from '../../../service/manga-service';

// Search form and results grid for the Manga tab on the home page.
@Component({
  selector: 'app-manga',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './manga.html',
  styleUrl: './manga.css',
})
export class Manga {
  protected query = '';
  protected results: MangaItem[] = [];
  protected loading = false;
  protected error = '';
  protected hasSearched = false;
  protected visibleCount = 0;
  private readonly batchSize = 6;

  private readonly mangaService = inject(MangaService);

  // Run the manga search pipeline and reflect progress/errors in the view.
  protected async onSearch(): Promise<void> {
    const trimmedQuery = this.query.trim();
    if (!trimmedQuery) {
      this.results = [];
      this.hasSearched = false;
      this.visibleCount = 0;
      return;
    }

    this.loading = true;
    this.error = '';
    this.hasSearched = true;

    try {
      this.results = await this.mangaService.searchManga(trimmedQuery);
      this.visibleCount = Math.min(this.batchSize, this.results.length);
    } catch {
      this.error = 'Search is temporarily unavailable. Please try again shortly.';
    } finally {
      this.loading = false;
    }
  }

  // Expose only the subset of results currently shown to the user.
  protected get visibleResults(): MangaItem[] {
    return this.results.slice(0, this.visibleCount || this.batchSize);
  }

  // Increase the number of rendered cards in fixed increments.
  protected showMoreResults(): void {
    this.visibleCount = Math.min(this.visibleCount + this.batchSize, this.results.length);
  }
}
