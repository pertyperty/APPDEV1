# FinalProject Setup Guide

## TL;DR

```bash
node -v        # v18.19+ or v20.x
npm install
npm install --save @tutkli/jikan-ts axios axios-cache-interceptor
npm run start  # serves at http://localhost:4200/
```

That’s all you need on a fresh machine. The sections below dive into the details if something goes wrong.

The project is an Angular 17/CLI 20.1 application that talks to the public Jikan API for anime/manga data. This guide walks through everything you need to run it on **any** device (Windows, macOS, or Linux).

## 1. System Requirements

- **Node.js**: v18.19 or v20.x LTS (check with `node -v`).
- **npm**: v10+ (ships with current Node releases; verify with `npm -v`).
- **Angular CLI**: 20.1.x globally (`npm install -g @angular/cli@20`).
- **Git** (if you are cloning the repository).

> Tip: If you are running this on a new machine, install Node via the official installer from [nodejs.org](https://nodejs.org/en) to get compatible npm binaries.

## 2. Clone & Install Dependencies

```bash
git clone <repo-url>
cd final-project
npm install
# Ensure the required API client packages are present
npm install --save @tutkli/jikan-ts axios axios-cache-interceptor
```

The last command installs the Jikan SDK plus the axios cache layer that our services rely on. You only need to run it once per machine, but it is safe to repeat.

## 3. Environment Configuration

Default environment files live under `src/environments/`. They already point to the public Jikan API, so you normally do **not** need extra keys. If you add your own back end later, update `environment.ts` / `environment.development.ts` accordingly.

## 4. Running the Dev Server

```bash
npm run start        # alias for ng serve
# or
ng serve --host 0.0.0.0 --port 4200
```

- Open `http://localhost:4200/` locally.
- To test from another device on the same network, visit `http://<your-local-ip>:4200/` (use `ipconfig`/`ifconfig` to find the address). Keep the dev server running in the same terminal.

If you see a blank page, open the browser console; runtime errors (e.g., missing packages, blocked network calls) will appear there.

## 5. Building for Production

```bash
ng build
```

The optimized bundle lands in `dist/final-project/`. Serve that folder with any static host (Nginx, Netlify, Vercel, etc.).

## 6. Testing

- **Unit tests** (Karma): `ng test`
- **E2E** (choose your framework): `ng e2e`

## 7. Common Issues

| Symptom | Fix |
| --- | --- |
| Blank screen + `NG0908` | Ensure `src/main.ts` imports `zone.js` (already included). |
| 500 error when loading bundles | The dev server isn’t running or another process is using port 4200; restart with `ng serve --port 4300`. |
| API calls blocked | Jikan enforces rate limits; wait a minute or proxy through your own back end. |

## 8. Useful Commands

| Command | Purpose |
| --- | --- |
| `npm run lint` | Run linting (if configured). |
| `ng generate component foo` | Scaffold a new component. |
| `ng build --configuration production` | Explicit production build with stricter budgets. |

## 9. Troubleshooting on New Machines

1. Delete `node_modules` and `package-lock.json` if the install becomes corrupted.
2. Re-run `npm install` and the `@tutkli/jikan-ts` dependency command above.
3. Clear the Angular cache if needed: `npx ng cache clean`.
4. Start the server again: `ng serve --open`.

Following these steps ensures the app boots consistently on any device with the required toolchain.
