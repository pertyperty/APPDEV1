import { Component } from '@angular/core';

@Component({
  selector: 'app-body',
  standalone: false,
  templateUrl: './body.component.html',
  styleUrl: './body.component.css'
})
export class BodyComponent {
  profile = 
  {
    
    name: 'Rupert Conde dela Cruz',
    title: 'Aiming to be a 10x Developer',
    about: 'Currently studying BS Computer Science in pursuit of the grandest of dreams.',
    quote: '"The reason I can now stand before the crowd\'s watchful gaze is perhaps because... I have finally started to act as myself"',
    skills: 
    ['Angular', 'Typescript', 'HTML/CSS', 'Responsive Design'],
    experience: 
    [
      {
        role: 'Virtual Assistant',
        company: 'City Supply',
        period: '2022 - Present',
        description: 'General back office tasks. Managing transactions, inventory, and product design.'
      }, 
      {
        role: 'Freelancer',
        company: 'Ultimate Autographs',
        period: '2020-2022',
        description: 'Data entry. Product design.',
      },
    ],

    education: 
    [
      {
        degree: 'Bachelor of Science in Computer Science',
        school: 'University of Baguio',
        year: 'Current'
      },
      {
        degree: 'High School',
        school: 'Bolinao Integrated School',
        year: '2018-2024'
      },
      {
        degree: 'Grade School',
        school: 'Bolinao Integrated School',
        year: '2012-2018'
      }
    ],

    awards:
    [
      {
        competition: 'Brainwave: Networking 1',
        placement: 'First Place',
        venue: 'University of Baguio',
        year: '2024'
      },
      {
        competition: 'Mathematical Investigation (Division Level)',
        placement: 'Second Place',
        venue: 'Pangasinan National High School',
        year: '2024',
      },
      /*{
        competition: '',
        placement: '',
        venue: '',
        year: ''
      }*/
    ],

    courses:
    [
      {
        code: 'GETHICS1',
        title: 'Ethics',
        instructor: 'Aira Jessa Palisoc',
      },
      {
        code: 'DSALGO1',
        title: 'Data Structures and Algorithm',
        instructor: 'Cherrie Almazan',
      },
      {
        code: 'APPDEV1',
        title: 'Introduction to Applications Development',
        instructor: 'Jeremy Moses Ebreo',
      },
      {
        code: 'IMDBSE1',
        title: 'Information Management and Database Systems',
        instructor: 'Divine Aguilar-Agudong',
      },
      {
        code: 'PROGIT2',
        title: 'Object-Oriented Programming',
        instructor: 'Meynard Soriano',
      },
      {
        code: 'DITRUC2',
        title: 'Discrete Structures 2',
        instructor: 'Jeremy Moses Ebreo',
      },
      {
        code: 'ITMGNT1',
        title: 'Project Management',
        instructor: 'Hydi Toyeng',
      },
      {
        code: 'PATHFT3D',
        title: 'Bowling',
        instructor: 'Lorie Daodao',
      },
    ],

    contact: 
    {
      email: 'rupertdelacruz8@gmail.com',
      phone: '(+63) 910 166 2192',
      location: 'Baguio, Philippines'
    }
  }
}
