import { Component } from '@angular/core';

@Component({
  selector: 'app-guide',
  standalone: false,
  templateUrl: './guide.html',
  styleUrl: './guide.css'
})
export class Guide {

}
