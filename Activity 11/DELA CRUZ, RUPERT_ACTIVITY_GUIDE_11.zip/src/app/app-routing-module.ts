import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Home } from './home/home';
import { Gym1 } from './gym-pages/gym-1/gym-1';
import { Gym2 } from './gym-pages/gym-2/gym-2';
import { Gym3 } from './gym-pages/gym-3/gym-3';
import { Gym4 } from './gym-pages/gym-4/gym-4';
import { Gym5 } from './gym-pages/gym-5/gym-5';
import { Gym6 } from './gym-pages/gym-6/gym-6';
import { Gym7 } from './gym-pages/gym-7/gym-7';
import { Gym8 } from './gym-pages/gym-8/gym-8';
import { TrainerForm } from './trainer-pages/trainer-form/trainer-form';
import { TrainerList } from './trainer-pages/trainer-list/trainer-list';
import { Berries } from './bag-pages/berries/berries';
import { Pokeballs } from './bag-pages/pokeballs/pokeballs';
import { Eevee } from './fav-pokemon-pages/eevee/eevee';
import { HoOh } from './fav-pokemon-pages/ho-oh/ho-oh';
import { Lugia } from './fav-pokemon-pages/lugia/lugia';
import { Suicune } from './fav-pokemon-pages/suicune/suicune';
import { Togepi } from './fav-pokemon-pages/togepi/togepi';
import { Totodile } from './fav-pokemon-pages/totodile/totodile';

const routes: Routes = [
  {path: '', component: Home, pathMatch: 'full'},
  {path: 'gym-1', component: Gym1},
  {path: 'gym-2', component: Gym2},
  {path: 'gym-3', component: Gym3},
  {path: 'gym-4', component: Gym4},
  {path: 'gym-5', component: Gym5},
  {path: 'gym-6', component: Gym6},
  {path: 'gym-7', component: Gym7},
  {path: 'gym-8', component: Gym8}, 
  {path: 'trainer-form', component: TrainerForm}, 
  {path: 'trainer-list', component: TrainerList}, 
  {path: 'berries', component: Berries}, 
  {path: 'pokeballs', component: Pokeballs}, 
  {path: 'eevee', component: Eevee}, 
  {path: 'ho-oh', component: HoOh}, 
  {path: 'lugia', component: Lugia}, 
  {path: 'suicune', component: Suicune}, 
  {path: 'togepi', component: Togepi}, 
  {path: 'totodile', component: Totodile}, 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
