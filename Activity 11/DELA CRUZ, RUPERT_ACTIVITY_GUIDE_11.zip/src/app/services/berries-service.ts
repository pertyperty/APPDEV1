import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BerriesService {
  getBerries() {
    return[
      {name: 'PRZ Cure Berry', effect: 'Cures Paralysis'},
      {name: 'Mint Berry', effect: 'Cures Sleep'},
      {name: 'PSN Cure Berry', effect: 'Cures Poison'},
      {name: 'Ice Berry', effect: 'Cures Burn'},
      {name: 'Burnt Berry', effect: 'Cures Freeze'},
      {name: 'Mystery Berry', effect: 'Restores 5 PP'},
      {name: 'Berry', effect: 'Restores 10 HP'},
      {name: 'Bitter Berry', effect: 'Cures Confusion'},
      {name: 'Miracle Berry', effect: 'Cures any non-volatile status condition and Confusion'},
      {name: 'Gold Berry', effect: 'Restores 30 HP'},
    ]
  }
}
