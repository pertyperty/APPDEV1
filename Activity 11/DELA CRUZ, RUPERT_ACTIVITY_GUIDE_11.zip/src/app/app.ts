import { Component, signal } from '@angular/core';
import { Gym1 } from './gym-pages/gym-1/gym-1';
import { Gym2 } from './gym-pages/gym-2/gym-2';
import { Gym3 } from './gym-pages/gym-3/gym-3';
import { Gym4 } from './gym-pages/gym-4/gym-4';
import { Gym5 } from './gym-pages/gym-5/gym-5';
import { Gym6 } from './gym-pages/gym-6/gym-6';
import { Gym7 } from './gym-pages/gym-7/gym-7';
import { Gym8 } from './gym-pages/gym-8/gym-8';
import { TrainerForm } from './trainer-pages/trainer-form/trainer-form';
import { TrainerList } from './trainer-pages/trainer-list/trainer-list';
import { Eevee } from './fav-pokemon-pages/eevee/eevee';
import { Totodile } from './fav-pokemon-pages/totodile/totodile';
import { HoOh } from './fav-pokemon-pages/ho-oh/ho-oh';
import { Lugia } from './fav-pokemon-pages/lugia/lugia';
import { Suicune } from './fav-pokemon-pages/suicune/suicune';
import { Togepi } from './fav-pokemon-pages/togepi/togepi';

@Component({
  selector: 'app-root',
  templateUrl: './app.html',
  standalone: false,
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('activity-11-remastered');

  SidebarTitle = "Gym Leaders";
  TitleEn = "Activity 11";
  TitleJp = "⠀";

  onRouteActivate(component: any) {
    if (component instanceof Gym1) {
      this.TitleEn = "Violet City";
      this.TitleJp = "キキョウシティ";
    } else if (component instanceof Gym2) {
      this.TitleEn = "Azalea Town";
      this.TitleJp = "ヒワダタウン";
    } else if (component instanceof Gym3) {
      this.TitleEn = "Goldenrod City";
      this.TitleJp = "コガネシティ";
    } else if (component instanceof Gym4) {
      this.TitleEn = "Ecruteak City";
      this.TitleJp = "エンジュシティ";
    } else if (component instanceof Gym5) {
      this.TitleEn = "Cianwood City";
      this.TitleJp = "タンバシティ";
    } else if (component instanceof Gym6) {
      this.TitleEn = "Olivine City";
      this.TitleJp = "アサギシティ";
    } else if (component instanceof Gym7) {
      this.TitleEn = "Mahogany Town";
      this.TitleJp = "チョウジタウン";
    } else if (component instanceof Gym8) {
      this.TitleEn = "Blackthorn City";
      this.TitleJp = "フスベシティ";
    } else if (component instanceof TrainerForm) {
      this.TitleEn = "Add Trainers"
      this.TitleJp = "⠀";
    } else if (component instanceof TrainerList) {
      this.TitleEn = "Trainer List"
      this.TitleJp = "⠀";
    } else if (component instanceof Eevee) {
      this.TitleEn = "Favorite Pokemons"
      this.TitleJp = "イーブイ";
    } else if (component instanceof HoOh) {
      this.TitleEn = "Favorite Pokemons"
      this.TitleJp = "ホウオウ";
    } else if (component instanceof Lugia) {
      this.TitleEn = "Favorite Pokemons"
      this.TitleJp = "ルギア";
    } else if (component instanceof Suicune) {
      this.TitleEn = "Favorite Pokemons"
      this.TitleJp = "スイクン";
    } else if (component instanceof Togepi) {
      this.TitleEn = "Favorite Pokemons"
      this.TitleJp = "トゲピー";
    } else if (component instanceof Totodile) {
      this.TitleEn = "Favorite Pokemons"
      this.TitleJp = "ワニノコ";
    } else {
      this.TitleEn = "Home";
      this.TitleJp = "⠀";
    }
  }
}
