import { Component } from '@angular/core';
import { InputForms } from '../../services/input-forms';

@Component({
  selector: 'app-trainer-form',
  standalone: false,
  templateUrl: './trainer-form.html',
  styleUrl: './trainer-form.css'
})
export class TrainerForm {
  constructor(public inputForm: InputForms) {}

  onSubmit(): void {
    this.inputForm.addTrainer();
  }
}
