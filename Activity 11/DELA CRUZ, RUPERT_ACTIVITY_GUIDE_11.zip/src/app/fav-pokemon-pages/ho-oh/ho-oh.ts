import { TitleCasePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { MatDividerModule } from '@angular/material/divider';

@Component({
  selector: 'app-ho-oh',
  standalone: true,
  imports: [
    MatDividerModule,
    TitleCasePipe,
  ],
  templateUrl: './ho-oh.html',
  styleUrl: './ho-oh.css'
})
export class HoOh {
pokemon: any;

  constructor(private http: HttpClient) {
    this.http.get('https://pokeapi.co/api/v2/pokemon/ho-oh').subscribe(
      response => {
      this.pokemon = response;
      },
      error => {
      console.error('Error:', error);
      }
    );
  }
}
