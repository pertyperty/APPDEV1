import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HoOh } from './ho-oh';

describe('HoOh', () => {
  let component: HoOh;
  let fixture: ComponentFixture<HoOh>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HoOh]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HoOh);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
