import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDividerModule } from '@angular/material/divider';

import { Evo0 } from './evolutions/evo0/evo0';
import { Evo1 } from './evolutions/evo1/evo1';
import { Evo2 } from './evolutions/evo2/evo2';

@Component({
  selector: 'app-totodile',
  standalone: true,
  imports: [
    CommonModule,
    MatDividerModule,
    Evo0,
    Evo1,
    Evo2
  ],
  templateUrl: './totodile.html',
  styleUrl: './totodile.css'
})

export class Totodile {

}
