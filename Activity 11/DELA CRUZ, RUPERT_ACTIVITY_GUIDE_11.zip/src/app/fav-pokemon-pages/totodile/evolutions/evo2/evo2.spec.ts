import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Evo2 } from './evo2';

describe('Evo2', () => {
  let component: Evo2;
  let fixture: ComponentFixture<Evo2>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Evo2]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Evo2);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
