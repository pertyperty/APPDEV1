import { TitleCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { MatDivider } from '@angular/material/divider';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-suicune',
  standalone: true,
  imports: [
    MatDivider,
    TitleCasePipe
  ],
  templateUrl: './suicune.html',
  styleUrl: './suicune.css'
})
export class Suicune {
  pokemon: any;

  constructor(private http: HttpClient) {
    this.http.get('https://pokeapi.co/api/v2/pokemon/suicune').subscribe(
      response => {
      this.pokemon = response;
      },
      error => {
      console.error('Error:', error);
      }
    );
  }
}
