import { TitleCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { MatDividerModule } from '@angular/material/divider';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-lugia',
  standalone: true,
  imports: [
    MatDividerModule,
    TitleCasePipe
  ],
  templateUrl: './lugia.html',
  styleUrl: './lugia.css'
})
export class Lugia {
  pokemon: any;

  constructor(private http: HttpClient) {
    this.http.get('https://pokeapi.co/api/v2/pokemon/lugia').subscribe(
      response => {
      this.pokemon = response;
      },
      error => {
      console.error('Error:', error);
      }
    );
  }
}
