import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDividerModule } from '@angular/material/divider';

import { Evo0 } from './evolutions/evo0/evo0';
import { Evo1 } from './evolutions/evo1/evo1';

@Component({
  selector: 'app-togepi',
  standalone: true,
  imports: [
    CommonModule,
    MatDividerModule,
    Evo0,
    Evo1
  ],
  templateUrl: './togepi.html',
  styleUrl: './togepi.css'
})

export class Togepi {

}
