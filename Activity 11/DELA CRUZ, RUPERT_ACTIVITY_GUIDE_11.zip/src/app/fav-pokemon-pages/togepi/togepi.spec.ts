import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Togepi } from './togepi';

describe('Togepi', () => {
  let component: Togepi;
  let fixture: ComponentFixture<Togepi>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Togepi]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Togepi);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
