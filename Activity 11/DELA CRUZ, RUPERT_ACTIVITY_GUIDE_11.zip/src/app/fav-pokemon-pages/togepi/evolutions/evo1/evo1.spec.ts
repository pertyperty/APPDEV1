import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Evo1 } from './evo1';

describe('Evo1', () => {
  let component: Evo1;
  let fixture: ComponentFixture<Evo1>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Evo1]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Evo1);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
