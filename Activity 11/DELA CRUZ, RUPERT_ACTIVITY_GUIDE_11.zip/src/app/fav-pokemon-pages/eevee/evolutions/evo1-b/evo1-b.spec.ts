import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Evo1B } from './evo1-b';

describe('Evo1B', () => {
  let component: Evo1B;
  let fixture: ComponentFixture<Evo1B>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Evo1B]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Evo1B);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
