import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatDividerModule } from '@angular/material/divider';
import { TitleCasePipe } from '@angular/common';

@Component({
  selector: 'app-evo1-b',
  standalone: true,
  imports: [
    MatDividerModule,
    TitleCasePipe
  ],
  templateUrl: './evo1-b.html',
  styleUrl: './evo1-b.css'
})

export class Evo1B {
  pokemon: any;

  constructor(private http: HttpClient) {
    this.http.get('https://pokeapi.co/api/v2/pokemon/jolteon').subscribe(
      response => {
      this.pokemon = response;
      },
      error => {
      console.error('Error:', error);
      }
    );
  }
}