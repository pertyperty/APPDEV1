import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Evo1A } from './evo1-a';

describe('Evo1A', () => {
  let component: Evo1A;
  let fixture: ComponentFixture<Evo1A>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Evo1A]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Evo1A);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
