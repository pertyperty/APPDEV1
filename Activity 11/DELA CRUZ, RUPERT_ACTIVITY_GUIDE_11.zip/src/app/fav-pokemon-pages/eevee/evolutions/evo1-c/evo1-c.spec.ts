import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Evo1C } from './evo1-c';

describe('Evo1C', () => {
  let component: Evo1C;
  let fixture: ComponentFixture<Evo1C>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Evo1C]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Evo1C);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
