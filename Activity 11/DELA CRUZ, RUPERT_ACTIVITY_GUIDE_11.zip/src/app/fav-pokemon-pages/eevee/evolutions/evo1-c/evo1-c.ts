import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatDividerModule } from '@angular/material/divider';
import { TitleCasePipe } from '@angular/common';

@Component({
  selector: 'app-evo1-c',
  standalone: true,
  imports: [
    MatDividerModule,
    TitleCasePipe
  ],
  templateUrl: './evo1-c.html',
  styleUrl: './evo1-c.css'
})

export class Evo1C {
  pokemon: any;

  constructor(private http: HttpClient) {
    this.http.get('https://pokeapi.co/api/v2/pokemon/flareon').subscribe(
      response => {
      this.pokemon = response;
      },
      error => {
      console.error('Error:', error);
      }
    );
  }
}