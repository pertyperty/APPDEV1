import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Evo1E } from './evo1-e';

describe('Evo1E', () => {
  let component: Evo1E;
  let fixture: ComponentFixture<Evo1E>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Evo1E]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Evo1E);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
