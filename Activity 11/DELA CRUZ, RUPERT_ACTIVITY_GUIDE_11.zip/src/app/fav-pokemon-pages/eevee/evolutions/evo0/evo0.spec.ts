import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Evo0 } from './evo0';

describe('Evo0', () => {
  let component: Evo0;
  let fixture: ComponentFixture<Evo0>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Evo0]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Evo0);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
