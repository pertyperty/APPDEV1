import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Evo1D } from './evo1-d';

describe('Evo1D', () => {
  let component: Evo1D;
  let fixture: ComponentFixture<Evo1D>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Evo1D]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Evo1D);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
