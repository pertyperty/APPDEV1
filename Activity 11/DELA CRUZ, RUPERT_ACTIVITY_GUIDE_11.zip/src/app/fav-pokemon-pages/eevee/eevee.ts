import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDividerModule } from '@angular/material/divider';

import { Evo0 } from './evolutions/evo0/evo0';
import { Evo1A } from './evolutions/evo1-a/evo1-a';
import { Evo1B } from './evolutions/evo1-b/evo1-b';
import { Evo1C } from './evolutions/evo1-c/evo1-c';
import { Evo1D } from './evolutions/evo1-d/evo1-d';
import { Evo1E } from './evolutions/evo1-e/evo1-e';

@Component({
  selector: 'app-eevee',
  standalone: true,
  imports: [
    CommonModule,
    MatDividerModule,
    Evo0,
    Evo1A,
    Evo1B,
    Evo1C,
    Evo1D,
    Evo1E
  ],
  templateUrl: './eevee.html',
  styleUrl: './eevee.css'
})

export class Eevee {

}