import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { TaotechingComponent } from './taoteching/taoteching.component';
import { MeditationsComponent } from './meditations/meditations.component';

const routes: Routes = [
  { path: '', redirectTo: '/meditations', pathMatch: 'full' },
  { path: 'taoteching', component: TaotechingComponent },
  { path: 'meditations', component: MeditationsComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
