import { Component } from '@angular/core';
import { MeditationsComponent } from './meditations/meditations.component';
import { TaotechingComponent } from './taoteching/taoteching.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.css'
})
export class AppComponent {
  Title = 'Activity 6';

  onRouteActivate(component: any) {
    if (component instanceof MeditationsComponent) {
      this.Title = "The Meditations of Marcus Aurelius";
    } else if (component instanceof TaotechingComponent) {
      this.Title = "Quotes from Tao Te Ching";
    } else {
      this.Title = "Activity 6";
    }
  }
}
