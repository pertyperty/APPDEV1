import { Component } from '@angular/core';

@Component({
  selector: 'app-taoteching',
  standalone: false,
  templateUrl: './taoteching.component.html',
  styleUrl: './taoteching.component.css'
})
export class TaotechingComponent {
taoTechingPhilosophy = [
    {
      book: 'Quote 1',
      body: 'Nature does not hurry, yet everything is accomplished.'
    },
    {
      book: 'Quote 2',
      body: 'Manifest plainness, embrace simplicity, reduce selfishness, have few desires.'
    },
    {
      book: 'Quote 3',
      body: 'Knowing yourself is true wisdom. Mastering yourself is true power.'
    },
    {
      book: 'Quote 4',
      body: 'The Master has no possessions. The more he does for others, the happier he is. The more he gives to others, the wealthier he is.'
    },
    {
      book: 'Quote 5',
      body: 'Nothing in the world is softer and weaker than water; but for attacking the hard and strong, there is nothing like it!'
    }
  ]

  currentIndex: number = 0;
  currentQuote = this.taoTechingPhilosophy[0];

  increment() {
    if (this.currentIndex < this.taoTechingPhilosophy.length - 1) {
      this.currentIndex++;
      this.currentQuote = this.taoTechingPhilosophy[this.currentIndex];
    }
    else if(this.currentIndex == this.taoTechingPhilosophy.length - 1){
      this.currentIndex = 0;
      this.currentQuote = this.taoTechingPhilosophy[this.currentIndex];
    }

  }

  decrement() {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.currentQuote = this.taoTechingPhilosophy[this.currentIndex];
    }
    if(this.currentIndex == 0){
      this.currentIndex = this.taoTechingPhilosophy.length - 1;
      this.currentQuote = this.taoTechingPhilosophy[this.currentIndex];
    }
  }
}
